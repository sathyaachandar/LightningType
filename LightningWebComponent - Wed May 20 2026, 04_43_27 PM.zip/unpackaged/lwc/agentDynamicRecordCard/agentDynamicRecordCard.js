import { LightningElement, api, track } from 'lwc';

export default class AgentDynamicRecordCard extends LightningElement {

    @track displayFields = [];
    @track _title = '';
    @track _subtitle = '';
    @track _iconName = 'standard:record';

    @api
    get value() {
        return this._value;
    }
    set value(val) {
        this._value = val;
        console.log('VALUE SET:', JSON.stringify(val));
        this.processData(val);
    }
    _value;

    processData(val) {
        if (!val) return;
        
        const data = val?.aRecord ?? val?.response ?? val;
        console.log('DATA:', JSON.stringify(data));

        this._title = data?.title ?? 'No Title';
        this._subtitle = data?.subtitle ?? '';
        this._iconName = data?.iconName ?? 'standard:record';

        if (data?.fields) {
            this.displayFields = data.fields.map(field => ({
                ...field,
                isBadge: field.type === 'badge'
            }));
        }
    }

    get title() { return this._title; }
    get subtitle() { return this._subtitle; }
    get iconName() { return this._iconName; }
}