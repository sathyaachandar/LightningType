import { LightningElement, api, track } from 'lwc';

export default class CpsAgentRecordCard extends LightningElement {

    // ─── Inputs from Flow / Agent ───────────────────────────────────────────

    /** Display title in the banner, e.g. "10372591" or "ORD-00123" */
    @api recordTitle = '';

    /** Label shown above the title, e.g. "Part Record" or "Order" */
    @api recordType = '';

    /**
     * JSON string — array of field objects:
     * [
     *   { "label": "Description",     "value": "TB33 General Drawing" },
     *   { "label": "Net Price",        "value": null },
     *   { "label": "Product Family",   "value": "Excavator Parts" }
     * ]
     */
    @api fieldsJson = '[]';

    /**
     * JSON string — array of action objects:
     * [
     *   { "label": "Parts Manual",  "icon": "utility:file",    "prompt": "Show parts manual for {recordTitle}" },
     *   { "label": "View BOM",      "icon": "utility:list",    "prompt": "Show BOM for {recordTitle}" },
     *   { "label": "Raise Case",    "icon": "utility:case",    "prompt": "Raise a support case for {recordTitle}" }
     * ]
     */
    @api actionsJson = '[]';

    /** SLDS icon name for the banner, e.g. "standard:product" or "standard:orders" */
    @api iconName = 'standard:product';

    /**
     * Banner color key — maps to an SLDS theme class:
     * blue (default) | green | red | orange | purple | teal
     */
    @api bannerColor = 'blue';

    /** Status badge text, e.g. "Active", "Pending", "Closed". Leave blank to hide. */
    @api statusLabel = '';

    /** Status badge variant: success | warning | error | default */
    @api statusVariant = 'success';

    /** Footer source text, e.g. "SANY Dealer Portal" */
    @api footerText = 'SANY Dealer Portal';

    // ─── Computed ───────────────────────────────────────────────────────────

    get bannerClass() {
        const colorMap = {
            blue:   'banner banner--blue',
            green:  'banner banner--green',
            red:    'banner banner--red',
            orange: 'banner banner--orange',
            purple: 'banner banner--purple',
            teal:   'banner banner--teal',
        };
        return colorMap[this.bannerColor] || colorMap.blue;
    }

    get statusBadgeClass() {
        const variantMap = {
            success: 'status-badge status-badge--success',
            warning: 'status-badge status-badge--warning',
            error:   'status-badge status-badge--error',
            default: 'status-badge status-badge--default',
        };
        return variantMap[this.statusVariant] || variantMap.success;
    }

    get parsedFields() {
        try {
            const raw = JSON.parse(this.fieldsJson || '[]');
            return raw.map(f => ({
                label:        f.label || '',
                displayValue: f.value != null && f.value !== '' ? String(f.value) : '—',
                valueClass:   f.value != null && f.value !== '' ? 'field-value' : 'field-value field-value--empty',
            }));
        } catch (e) {
            return [];
        }
    }

    get parsedActions() {
        try {
            const raw = JSON.parse(this.actionsJson || '[]');
            // Replace {recordTitle} placeholder in prompts
            return raw.map(a => ({
                label:  a.label  || '',
                icon:   a.icon   || 'utility:forward',
                prompt: (a.prompt || '').replace(/\{recordTitle\}/g, this.recordTitle),
            }));
        } catch (e) {
            return [];
        }
    }

    get hasActions() {
        return this.parsedActions.length > 0;
    }

    get isEmpty() {
        return this.parsedFields.length === 0;
    }

    // ─── Handlers ───────────────────────────────────────────────────────────

    handleAction(event) {
        const prompt = event.currentTarget.dataset.prompt;
        if (!prompt) return;

        // Fire a custom event — the parent Flow / Experience page can listen
        this.dispatchEvent(new CustomEvent('agentprompt', {
            detail: { prompt },
            bubbles: true,
            composed: true,
        }));

        // If embedded in Embedded Service Chat, post to the chat window
        try {
            const chatAPI = window.embeddedservice_bootstrap?.utilAPI;
            if (chatAPI) {
                chatAPI.sendTextMessage(prompt);
            }
        } catch (e) {
            // Not in embedded chat context — no-op
        }
    }
}