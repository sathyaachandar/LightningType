import { LightningElement, api,track } from 'lwc';

export default class AgentforceRecordResponse extends LightningElement {

    @api value;

    
}